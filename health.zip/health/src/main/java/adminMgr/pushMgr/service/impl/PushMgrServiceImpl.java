package adminMgr.pushMgr.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import adminMgr.pushMgr.service.PushMgrService;

@Service
@Transactional
public class PushMgrServiceImpl implements PushMgrService {

	
	
}
