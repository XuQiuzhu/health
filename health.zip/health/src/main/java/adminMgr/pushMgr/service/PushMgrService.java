package adminMgr.pushMgr.service;

public interface PushMgrService {

}
