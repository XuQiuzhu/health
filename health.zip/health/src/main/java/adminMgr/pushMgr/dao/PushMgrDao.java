package adminMgr.pushMgr.dao;

public interface PushMgrDao {

}
