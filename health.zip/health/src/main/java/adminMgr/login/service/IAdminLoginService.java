package adminMgr.login.service;

import java.util.Map;

public interface IAdminLoginService {

	public String adminLogin(Map<String, Object> param) ;
	
}
