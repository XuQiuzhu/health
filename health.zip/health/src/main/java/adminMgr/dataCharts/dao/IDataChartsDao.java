package adminMgr.dataCharts.dao;

public interface IDataChartsDao {

}
