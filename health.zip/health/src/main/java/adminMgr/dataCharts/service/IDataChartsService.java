package adminMgr.dataCharts.service;

public interface IDataChartsService {

}
