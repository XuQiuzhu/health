﻿HighchartsJS v6.0.7（2018-02-16）



使用协议：https://www.highcharts.com.cn/license

更新日志：https://www.hcharts.cn/docs/changelog/highcharts
在线实例：https://www.hcharts.cn/demos/highcharts
使用教程： https://www.hcharts.cn/docs

API 文档： https://api.hcharts.cn/highcharts

Copyright @ 2018 Highsoft AS (http://highsoft.com)

中国地区由杭州简数科技有限公司提供服务（https://jianshukeji.com）